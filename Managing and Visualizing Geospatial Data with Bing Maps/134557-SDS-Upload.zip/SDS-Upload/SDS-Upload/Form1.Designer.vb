﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtFileName = New System.Windows.Forms.TextBox()
        Me.ofdPickFile = New System.Windows.Forms.OpenFileDialog()
        Me.btnFile = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtDataSourceName = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtBingMapsMasterKey = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtStatusUrl = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.ddInputFormat = New System.Windows.Forms.ComboBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.cbIncremental = New System.Windows.Forms.CheckBox()
        Me.cbMakePublic = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnFile)
        Me.GroupBox1.Controls.Add(Me.txtFileName)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Step 1: Select a Data-File"
        '
        'txtFileName
        '
        Me.txtFileName.Location = New System.Drawing.Point(7, 20)
        Me.txtFileName.Name = "txtFileName"
        Me.txtFileName.Size = New System.Drawing.Size(395, 20)
        Me.txtFileName.TabIndex = 0
        '
        'btnFile
        '
        Me.btnFile.Location = New System.Drawing.Point(408, 19)
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(33, 23)
        Me.btnFile.TabIndex = 1
        Me.btnFile.Text = "..."
        Me.btnFile.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtDataSourceName)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 123)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Step 3: Provide a Data-Source Name"
        '
        'txtDataSourceName
        '
        Me.txtDataSourceName.Location = New System.Drawing.Point(7, 20)
        Me.txtDataSourceName.Name = "txtDataSourceName"
        Me.txtDataSourceName.Size = New System.Drawing.Size(434, 20)
        Me.txtDataSourceName.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtBingMapsMasterKey)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 178)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Step 4: Provide your Bing Maps Master-Key"
        '
        'txtBingMapsMasterKey
        '
        Me.txtBingMapsMasterKey.Location = New System.Drawing.Point(7, 20)
        Me.txtBingMapsMasterKey.Name = "txtBingMapsMasterKey"
        Me.txtBingMapsMasterKey.Size = New System.Drawing.Size(434, 20)
        Me.txtBingMapsMasterKey.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnUpload)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 288)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Step 6: Upload Data"
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(8, 19)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(433, 23)
        Me.btnUpload.TabIndex = 1
        Me.btnUpload.Text = "Upload"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtStatusUrl)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 343)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Step 7: Monitor Status"
        '
        'txtStatusUrl
        '
        Me.txtStatusUrl.Location = New System.Drawing.Point(7, 20)
        Me.txtStatusUrl.Name = "txtStatusUrl"
        Me.txtStatusUrl.Size = New System.Drawing.Size(434, 20)
        Me.txtStatusUrl.TabIndex = 0
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.ddInputFormat)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 68)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox6.TabIndex = 4
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Step 2: Select Input Format"
        '
        'ddInputFormat
        '
        Me.ddInputFormat.FormattingEnabled = True
        Me.ddInputFormat.Items.AddRange(New Object() {"xml", "csv", "tab", "pipe", "kml", "shp"})
        Me.ddInputFormat.Location = New System.Drawing.Point(8, 20)
        Me.ddInputFormat.Name = "ddInputFormat"
        Me.ddInputFormat.Size = New System.Drawing.Size(433, 21)
        Me.ddInputFormat.TabIndex = 0
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.cbMakePublic)
        Me.GroupBox7.Controls.Add(Me.cbIncremental)
        Me.GroupBox7.Location = New System.Drawing.Point(13, 233)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(447, 49)
        Me.GroupBox7.TabIndex = 4
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Step 5: Options"
        '
        'cbIncremental
        '
        Me.cbIncremental.AutoSize = True
        Me.cbIncremental.Location = New System.Drawing.Point(322, 19)
        Me.cbIncremental.Name = "cbIncremental"
        Me.cbIncremental.Size = New System.Drawing.Size(118, 17)
        Me.cbIncremental.TabIndex = 0
        Me.cbIncremental.Text = "Incremental Upload"
        Me.cbIncremental.UseVisualStyleBackColor = True
        '
        'cbMakePublic
        '
        Me.cbMakePublic.AutoSize = True
        Me.cbMakePublic.Location = New System.Drawing.Point(7, 19)
        Me.cbMakePublic.Name = "cbMakePublic"
        Me.cbMakePublic.Size = New System.Drawing.Size(85, 17)
        Me.cbMakePublic.TabIndex = 1
        Me.cbMakePublic.Text = "Make Public"
        Me.cbMakePublic.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 403)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Upload to SDS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnFile As Button
    Friend WithEvents txtFileName As TextBox
    Friend WithEvents ofdPickFile As OpenFileDialog
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtDataSourceName As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtBingMapsMasterKey As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents btnUpload As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtStatusUrl As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents ddInputFormat As ComboBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents cbMakePublic As CheckBox
    Friend WithEvents cbIncremental As CheckBox
End Class
