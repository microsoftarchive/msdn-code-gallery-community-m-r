﻿Imports System.IO
Imports System.Net
Imports System.Text

Public Class Form1

    Dim ext As String = ""

    Private Sub btnFile_Click(sender As Object, e As EventArgs) Handles btnFile.Click
        ofdPickFile.InitialDirectory = "c:\"
        ofdPickFile.Filter = "All files (*.*)|*.*"
        ofdPickFile.FilterIndex = 1

        If ofdPickFile.ShowDialog() = DialogResult.OK Then
            Try
                txtFileName.Text = ofdPickFile.FileName
                ext = Path.GetExtension(ofdPickFile.FileName)
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        Try
            ' Custom name of spatial data source created during upload.
            Dim dataSourceName As String = txtDataSourceName.Text
            ' Path to the spatial data input file to be uploaded.
            Dim dataFilePath As String = txtFileName.Text
            ' The master key used for uploading to Spatial Data Services.
            ' This key should differ from your query key.
            Dim bingMapsMasterKey As String = txtBingMapsMasterKey.Text
            ' Create the spatial data upload URL.
            ' Here we use only complete upload which replaces existing data sources
            ' incremental upoads that add to existing data sources are also possible
            Dim queryStringBuilder As New StringBuilder()
            queryStringBuilder.Append("dataSourceName=")
            queryStringBuilder.Append(Uri.EscapeUriString(dataSourceName))
            If cbMakePublic.Checked = True Then
                queryStringBuilder.Append("&setPublic=1")
            Else
                queryStringBuilder.Append("&setPublic=0")
            End If

            If cbIncremental.Checked = True Then
                queryStringBuilder.Append("&loadOperation=incremental")
            Else
                queryStringBuilder.Append("&loadOperation=complete")
            End If
            ' Add Input Format.
            queryStringBuilder.Append("&input=")
            queryStringBuilder.Append(ddInputFormat.SelectedItem.ToString)
            queryStringBuilder.Append("&output=xml")
            queryStringBuilder.Append("&key=")
            queryStringBuilder.Append(Uri.EscapeUriString(bingMapsMasterKey))
            Dim uriBuilder As New UriBuilder("http://spatial.virtualearth.net")
            uriBuilder.Path = "/REST/v1/Dataflows/LoadDataSource"
            uriBuilder.Query = queryStringBuilder.ToString()
            Dim dataflowJobUrl As String = Nothing
            Using dataStream As FileStream = File.OpenRead(dataFilePath)
                Dim request As HttpWebRequest = DirectCast(WebRequest.Create(uriBuilder.Uri), HttpWebRequest)
                ' The HTTP method must be 'POST'.
                request.Method = "POST"
                request.ContentType = "text/plain"
                Using requestStream As Stream = request.GetRequestStream()
                    Dim buffer As Byte() = New Byte(16383) {}
                    Dim bytesRead As Integer = dataStream.Read(buffer, 0, buffer.Length)
                    While bytesRead > 0
                        requestStream.Write(buffer, 0, bytesRead)
                        bytesRead = dataStream.Read(buffer, 0, buffer.Length)
                    End While
                End Using
                ' Submit the HTTP request and check if the job was created successfully.
                Using response As HttpWebResponse = DirectCast(request.GetResponse(), HttpWebResponse)
                    '
                    ' If the job was created successfully, the status code should be
                    ' 201 (Created) and the 'Location' header should contain a URL
                    ' that defines the location of the new dataflow job. You use this
                    ' URL with the Bing Maps Key to query the status of your job.
                    '
                    dataflowJobUrl = response.GetResponseHeader("Location")
                    Dim jobStatusQueryUrl As String = String.Format("{0}?o=xml&key={1}", dataflowJobUrl, Uri.EscapeUriString(bingMapsMasterKey))

                    txtStatusUrl.Text = jobStatusQueryUrl

                    MessageBox.Show(response.StatusCode)
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
End Class
