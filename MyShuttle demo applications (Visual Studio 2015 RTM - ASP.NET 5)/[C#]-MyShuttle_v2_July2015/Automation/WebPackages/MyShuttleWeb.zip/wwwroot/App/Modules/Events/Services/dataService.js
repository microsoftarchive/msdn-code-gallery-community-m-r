'use strict';

angular.module('myShuttleEvents').service('eventsDataService', ['$http', '$q',
    function ($http, $q) {
        var service = this;
    }
]);
