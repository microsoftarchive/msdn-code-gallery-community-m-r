﻿
namespace MyShuttle.Data
{
    using Microsoft.Data.Entity;

    /// <summary>
    /// MyShuttle DbContext configuration
    /// </summary>
    public class MyShuttleDbContextOptions : DbContextOptions
    {
        /// <summary>
        ///  Default Admin user 
        /// </summary>
        public string DefaultAdminUserName { get; set; }

        /// <summary>
        /// Default admin password
        /// </summary>
        public string DefaultAdminPassword { get; set; }

    }
}