﻿using System;

namespace MyShuttle.Data
{
    public interface ICustomerRepository
    {

    }
}