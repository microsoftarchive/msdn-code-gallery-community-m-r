﻿
namespace MyShuttle.Model
{
    using System;

    public class EventMessage
    {
        public string Time { get; set; }

        public string DeviceId { get; set; }

        public string Message { get; set; }
    }
}